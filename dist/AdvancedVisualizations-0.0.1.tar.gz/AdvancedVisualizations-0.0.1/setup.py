import setuptools

setuptools.setup(
    name='AdvancedVisualizations',
    version='0.0.1',
    author='Peter Jachim',
    description='AdvancedVisualizations is a library that provides different types of plots.',
    packages=['AdvancedVisualizations']
)